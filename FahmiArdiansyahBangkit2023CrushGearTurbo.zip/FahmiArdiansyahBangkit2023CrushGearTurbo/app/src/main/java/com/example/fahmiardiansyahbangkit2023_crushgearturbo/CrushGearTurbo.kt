package com.example.fahmiardiansyahbangkit2023_crushgearturbo

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CrushGearTurbo(

    val img_CrushGearTurbo: Int,
    val name_CrushGearTurbo: String,
    val description_CrushGearTurbo: String,
    val detail_CrushGearTurbo: String

):Parcelable